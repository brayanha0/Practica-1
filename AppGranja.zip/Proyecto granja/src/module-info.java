module MyApp {
}