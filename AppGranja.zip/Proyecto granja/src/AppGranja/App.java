package AppGranja;

import java.io.FileNotFoundException;

import AppGranja.Vacas;

import AppGranja.Cabras;

public class App {



		static void run() throws FileNotFoundException {
			Vacas v= new Vacas();
			v.imprimeDatos();
			v.imprimePromedio();
			v.imprimeMaxProduccion();
			
			Cabras c= new Cabras();
			c.imprimeDatos();
			c.imprimePromedio();
			c.imprimeMaxProduccion();
		}
		
		public static void main(String[] args) throws FileNotFoundException {
	        run();
		}

	}
