package AppGranja;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Cabras {

	final int N=500;
	private int limite;
	private Animales lista[];
	
	public Cabras() throws FileNotFoundException {
		limite=0;
		lista= new Animales[N];
		cargaCabras();
	}
	
    private void cargaCabras() throws FileNotFoundException  {
    	Scanner input;

				input = new Scanner(new FileInputStream("DatosVacas.txt"));
				input.useDelimiter(";");
		    	while(input.hasNext()) {
		    		String c= input.next();
		    		String f=input.next();
		    		float e=input.nextFloat();
		    		String r=input.next();
		    		float l=input.nextFloat();
		    		float ms=input.nextFloat();
		    		float a=input.nextFloat();
		    		lista[limite++]= new Animales(c,f,e,r,l,ms,a);
		    	}
		    	input.close();
			
    }
	
    private float getPromediodeLeche() {
    	float promedio=0;
    	for(int i=0;i<limite;i++)
    		promedio+=lista[i].getLitros();
    	return promedio/limite;
    }
    
    private float getMaxProduccion() {
    	float mventas=0;
    	for(int i=0;i<limite;i++)
    		if(lista[i].getLitros()>mventas)
    			mventas=lista[i].getLitros();
    	return mventas;
    }
    
    public void imprimeDatos() {
    	for(int i=0;i<limite;i++) {
    		System.out.print("Cabras");
    		System.out.print("\t"+lista[i].getRaza());
    		System.out.print(lista[i].getCodigo()+"Codigo");
    		System.out.print("\t"+lista[i].getFecha()+"Adquisicion");
    		System.out.print("\t"+lista[i].getEdad()+"Años");
    		System.out.print("\t"+lista[i].getLitros()+"ltr.");
    		System.out.print("\t"+lista[i].getMesesySemanas());
    		System.out.print("\t"+lista[i].getA�o());
    		System.out.println("\t"+lista[i].getCantidadLecheVacas());
    	}
    }
	
    public void imprimePromedio() {
    	System.out.println("El Promedio de leche es="+getPromediodeLeche());
    }
    
    public void imprimeMaxProduccion() {
    	float mventas=getMaxProduccion();
    	System.out.println("La maxima produccion es de="+mventas);
    	System.out.println("Los codigos de los animales con mas produccion son:");
    	for(int i=0;i<limite;i++)
    		if(lista[i].getLitros()==mventas)
    			System.out.println(lista[i].getCodigo());
    }

}


