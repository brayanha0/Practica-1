package AppGranja;

public class Animales {
		
		private String codigo;
		private String fecha;
		private float edad;
		private String raza;
		private float litros;
		private float mys;
		private float a�o;
		
		public Animales (String codigo,String fecha,float edad, String raza, float litros, float mys, float a�o) {
			this.codigo=codigo;
			this.fecha=fecha;
			this.edad=edad;
			this.raza=raza;
			this.litros=litros;
			this.mys=mys;
			this.a�o=a�o;
		}

		public String getCodigo() {
			return codigo;
		}

		public String getFecha() {
			return fecha;
		}

		public float getEdad() {
			return edad;
		}
		public String getRaza() {
			return raza;
		}
		public float getLitros() {
			return litros;
		}
		public float getMesesySemanas() {
			return mys;
		}
		public float getA�o() {
			return a�o;
		}
		
		public float getCantidadLecheVacas() {
			float Csemana=litros*mys*a�o;
			
			return Csemana;
		}

	}
